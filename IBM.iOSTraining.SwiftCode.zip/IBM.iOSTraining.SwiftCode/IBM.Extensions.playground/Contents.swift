
extension Double {
    var km: Double { return self * 1_000.0 }
    var m : Double { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}

let oneInch = 25.4.mm
print(oneInch)

let threeFeet = 3.ft
print(threeFeet)

let aMarathon = 42.km + 195.m
print("Marathon is \(aMarathon) meters long")

let kiloMeter = 1.2.km
print(kiloMeter)


struct Size {
    var width = 0.0, height = 0.0
}
struct Point {
    var x = 0.0, y = 0.0
}
struct Rect {
    var origin = Point()
    var size   = Size()
}

let defaultRect = Rect()
let memberwiseRect = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))

extension Rect {
    init(center: Point, size: Size) {
        let originX = center.x - ( size.width / 2 )
        let originY = center.y - ( size.height / 2 )
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}
let centerRect = Rect(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height: 3.0 ))


extension Int {
    func repetitions(task: () -> ()) {
        for _ in 0..<self {
            task()
        }
    }
    mutating func square(){
        self = self * self
    }
}

3.repetitions(task: { print("Hello World!") } )
4.repetitions(task: { print("Ding Dong")} )
//print(4.square())

var numbers: [Int] = [10, 20, 30, 40, 50]
print(numbers)
for index in 0..<numbers.count {
    numbers[index].square()
    //print(number.square())
}
print(numbers)


var some: Int = 10
some.square()
print(some)

//One More Beauty!

extension Int {
    subscript(digitIndex: Int) -> Int {
        var digitIndex = digitIndex
        var decimalBase = 1
        while digitIndex > 0 {
            decimalBase *= 10
            digitIndex  -= 1
        }
        return ( self / decimalBase ) % 10
    }
}

745689789695[0]
745689789695[1]
745689789695[2]
745689789695[3]
745689789695[4]
745689789695[5]
745689789695[6]

// One More Beauty!

extension Int {
    enum Kind {
        case Negative, Zero, Positive
    }
    var kind: Kind {
        switch self {
        case 0:
            return .Zero
        case let x where x > 0:
            return .Positive
        default:
            return .Negative
        }
    }
}
func integerKind(numbers: [Int]) {
    for number in numbers {
        switch number.kind {
        case .Negative:
            print("- ", terminator: "")
        case .Positive:
            print("+ ", terminator: "")
        case .Zero:
            print("0 ", terminator: "")
        }
    }
}


print(4.kind)
print((-14).kind)
print(0.kind)

integerKind(numbers: [10, -10, 100, -90, 0, 1000])
var someNumber: Int = 100
someNumber.square()
print(someNumber)
print(someNumber.kind)
print(someNumber[0])
print(someNumber[4])

