

let  pi = 3.14159
let anotherPi = 3 + 0.14159


//: ## Numeric Literals
let decimalInteger = 17
print(decimalInteger)

let binaryInteger = 0b10001
print(binaryInteger)

let octalInteger = 0o21
print(octalInteger)

let hexadecimalInteger = 0x11
print(hexadecimalInteger)


//let hexFloat = 0x1234.0x5678

1.25e2
1.25e-2

0xFp2
0x8p4

let decimalDouble = 12.1875
let exponentDouble = 1.21875e1
let hexadecialDouble = 0xC.3p0

let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1

//: ## Numeric Conversion
//: ### Integer Conversion
//let cannotBeNegative: UInt8 = -1
//let tooBig: Int8 = Int8.max + 1
let twoThousand: UInt16 = 2_000
let one: UInt8 = 1
let twoThousandAndOne = twoThousand + UInt16(one)

//: ### Integer and Floating Point Conversion
let three = 3
let pointOneFourOneFiveNine = 0.14159
let pi2 = Double(three) + pointOneFourOneFiveNine

let integerPi = Int(pi)
// Floats are always truncated when cast to Integers
let integerFourPointSeven = Int(4.75)
let integerNegativeThreePointNine = Int(-3.9)


