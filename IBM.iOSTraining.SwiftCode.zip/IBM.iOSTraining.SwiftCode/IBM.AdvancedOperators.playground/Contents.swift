
let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits

let initialOctal: UInt8 = 0o76
let invertedOctal = ~initialOctal

let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8  = 0b00111111
let middleFourBits = firstSixBits & ~lastSixBits

var lastBitBits: UInt8  = 0b00111111

struct Vector2D {
    var x = 0.0, y = 0.0
}

func + (left: Vector2D, right: Vector2D) -> Vector2D {
    return Vector2D(x: left.x + right.x, y: left.y + right.y)
}

func += (left: inout Vector2D, right: Vector2D) {
    left = left + right
}

prefix func - (vector: Vector2D) -> Vector2D {
    return Vector2D(x: -vector.x, y: -vector.y)
}

func == (left: Vector2D, right: Vector2D) -> Bool {
    return (left.x == right.x) && (left.y == right.y)
}

var vector = Vector2D(x: 3.0, y: 1.0)
let anotherVector = Vector2D   (x: 2.0, y: 4.0 )

let combinedVector = vector + anotherVector
let negativeOfVector = -vector
print(combinedVector)
print(negativeOfVector)
vector += negativeOfVector
print(vector)

/*
infix operator +- { associativity left precedence 140 }
func +- (left: Vector2D, right: Vector2D) -> Vector2D {
    return Vector2D(x: left.x + right.x, y: left.y - right.y)
}
let firstVector = Vector2D(x: 1.0, y: 2.0)
let secondVector = Vector2D(x: 3.0, y: 4.0)
let plusMinusVector = firstVector +- secondVector
*/


