enum VendingMachineError: Error {
    case InvalidSelection
    case InsufficientFunds(required: Int)
    case OutOfStock
}

