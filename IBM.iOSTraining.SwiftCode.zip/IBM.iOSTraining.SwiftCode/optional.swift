var possibleNumber = "123"

var convertedNumber = Int(possibleNumber)
if convertedNumber != nil {
    print(convertedNumber)
    print(convertedNumber!)
} else {
    print("\(possibleNumber) Can't be converted")
}

if var actualNumber = Int(possibleNumber) {
    actualNumber = actualNumber + 100
    print("\(possibleNumber) has integer value \(actualNumber)")
} else {
    //print("\(possibleNumber) has integer value \(actualNumber)")
    print("\(possibleNumber) Can't be converted")
}

/*
if let firstNumber = Int("42"), let secondNumber = Int("444"), 
   firstNumber < secondNumber {
	print("\(firstNumber) < \(secondNumber)")
}

let fortyTwoTemp = Int("42")
let tripleFourTemp = Int("444")
if fortyTwoTemp != nil {
	let firstNumber = fortyTwoTemp!
	if tripleFourTemp != nil {
		let secondNumber = tripleFourTemp!
		if firstNumber < secondNumber {
			print("\(firstNumber) < \(secondNumber)")
		}
	}
}

*/


let a: Int? = 4
let b: Int? = nil
let c: Int? = 8

if let A = a, let B = b, let C = c {
	print(A, B, C)
} else {
	print("One of the thing is nil")
}

let enteredDoorCode = true
let passedRetinaScan = false

if enteredDoorCode && passedRetinaScan {
	print("Welcome")
} else {
	print("Pongoooo")
}



