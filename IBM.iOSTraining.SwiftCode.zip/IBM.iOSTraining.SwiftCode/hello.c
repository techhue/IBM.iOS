#include <stdio.h>

int main() {
	char i = 0;
/*
//	unsigned int x = 10;
	x = -127;
	char greeting[] = "Hello World!";
	
	printf("%s, %d", greeting, x);
*/

	for( i = 0 ; i < 255; i++)
	{
		printf("\n%d", i);
	}
	return 0;
}

