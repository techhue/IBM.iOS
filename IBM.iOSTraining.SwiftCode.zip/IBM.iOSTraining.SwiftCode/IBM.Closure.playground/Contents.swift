let names = ["Kat", "Ash", "Alex", "Deep",  "Samanta"]

func backwards(s1: String, s2: String) -> Bool {
    return s1 > s2
}

func forwards(s1: String, s2: String) -> Bool {
    return s1 < s2
}


var reversed = names.sorted(by: backwards)
print(reversed)

var ascending = names.sorted(by: forwards)
print(ascending)

reversed = names.sorted( by: {
        (s1: String, s2: String) -> Bool in return s1 > s2 })
print(reversed)

reversed = names.sorted( by: {
    (s1, s2) in return s1 > s2 })
print(reversed)

reversed = names.sorted( by: {
    (s1, s2) in s1 > s2 })
print(reversed)

reversed = names.sorted( by: { $0 > $1 })
print(reversed)

reversed = names.sorted( by: >)
print(reversed)

reversed = names.sorted( by: <)
print(reversed)

