class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}

let library: [Any] = [Movie(name:"Tare Zameen Par", director: "Ding"),
               Song(name:"Ek Ladki Ko Dekha", artist: "Kumar Sanu"),
               Movie(name: "ABCD", director: "Prabhu Deva"),
               Movie(name: "Baag Milkha Baag", director: "Some Director"),
               Movie(name: "3 Idiots", director: "Rajkumar"),
               Movie(name: "Padamavati", director: "Sanjay Leela Bansali        "),
               Song(name: "Waka Waka", artist: "Shakira"),
               Song(name: "Echak Dana Beechak Dana", artist: "Kishor Kumar"),
               "Ding", "Dong"
                ]
//print(library)

var movieCount = 0
var songCount = 0
for item in library {
    if item is Movie {
        movieCount += 1
        //print(item.name, item.director)
    } else if item is Song {
        songCount += 1
        //print(item.name, item.artist)
    }
}
print(movieCount, songCount)

for item in library {
    if let movie = item as? Movie {
        print(movie.name, movie.director)
    } else if let song = item as? Song {
        print(song.name, song.artist)
    } else {
        print("Type Conversion Failed")
    }
}

let someObjects: [AnyObject] = [
    Movie(name: "2001: A Space Odyssey", director: "Stanley Kubrick"),
    Movie(name: "Moon", director:"Duncan Jones"),
    Movie(name: "Alien", director: "Ridley Scott")
    //Song(name: "Waka Waka", artist: "Shakira")
]

for object in someObjects {
    let movie = object as! Movie
    print(movie.name, movie.director)
}

for object in someObjects as! [Movie] {
    print(object.name, object.director)
}

var things = [Any]()

things.append(0)
things.append(0.0)
things.append(42)
things.append(3.1459)
things.append("hello")
things.append((3.0, 5.0))
things.append(Movie(name: "Ghostbusters", director: "Ivan Reitman"))

print(things)

for thing in things {
    switch thing {
    case 0 as Int:
        print("zero as an Int")
    case 0 as Double:
        print("zero as a Double")
    case let someInt as Int:
        print("an integer value of \(someInt)")
    case let someDouble as Double where someDouble > 0:
        print("a positive double value of \(someDouble)")
    case is Double:
        print("some other double value that I don't want to print")
    case let someString as String:
        print("a string value of \"\(someString)\"")
    case let (x, y) as (Double, Double):
        print("an (x, y) point at \(x), \(y)")
    case let movie as Movie:
        print("a movie called '\(movie.name)', dir. \(movie.director)")
    default:
        print("something else")
    }
}


var moreThings: [Any] = []


