struct IntStack {
    var items = [Int]()
    mutating func push(item: Int) {
        items.append(item)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
}

struct StringStack {
    var items = [String]()
    mutating func push(item: String) {
        items.append(item)
    }
    mutating func pop() -> String {
        return items.removeLast()
    }
}

//Generics
struct Stack<T> {
    var items = [T]()
    mutating func push(item: T) {
        items.append(item)
    }
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var stackOfString = Stack<String>()
stackOfString.push(item: "Ding")
stackOfString.push(item: "Dong")
stackOfString.push(item: "King")
stackOfString.push(item: "Kong")
stackOfString.push(item: "Ming")
stackOfString.push(item: "Mong")

print(stackOfString.pop())
print(stackOfString.pop())


var stackOfInt = Stack<Int>()
stackOfInt.push(item: 100)
stackOfInt.push(item: 200)
stackOfInt.push(item: 3000)
stackOfInt.push(item: 10)
stackOfInt.push(item: -90)
stackOfInt.push(item: 80)

print(stackOfInt.pop())
print(stackOfInt.pop())

