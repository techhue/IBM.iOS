var str = "Hello World"
print(str)

var a: Int = 10
//a = Int.max + 1

var c: Int8 = 127
var inc: Int8 = 1
//c = c + inc

var ding = "Ding Dong"

let minValue = UInt8.min
let maxValue = UInt8.max

let pi = 3.14159
let anotherPi = 3 + 0.14159

//Various Representations
let decimalInteger = 17
let binaryInteger = 0b10001
let octalInteger = 0o21
let hexadecimalInteger = 0x11

let decimalDouble = 12.1875
let exponentDouble = 1.21875e1
let hexadecimalDouble = 0xC.3p0

let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1

//let twoThousand: UInt16 = 2_000
let twoThousand: UInt16 = 2
let one: UInt8 = 1
//let twoThousandAndOne = twoThousand + UInt16(one)
let twoThousandAndOne = UInt8(twoThousand) + one

let three = 3
let pointerOneFourOneFiveNine = 0.14159
let pi2 = Double(three) + pointerOneFourOneFiveNine

//var four = 4
//four = "Ding Dong"

typealias AudioSample = UInt16
var macAmplitude: AudioSample
macAmplitude = AudioSample.min

typealias Colors = UInt8
var pallet: Colors = 1

let orangesAreOrange: Bool = true
let turnipsAreDelicious = false

if turnipsAreDelicious {
    print("Tasty Turnips")
} else {
    print("Pata Nahin Kya Khayaaa....")
}

let integerPi = Int(pi)
let int16Value: Int16 = 20
let int8Value: Int8 = Int8(int16Value)

/*
let i = 1
//let ivalue = Bool(i)
if i {
    print("Oyeee Maaaa")
}
*/

let http404Error = (404, "Not Found")
let (statusCode, statusMessage) = http404Error
print("The status code is:", statusCode)
print("The status code is: \(statusCode)")
print("The Status Message is: \(statusMessage)")

let (justTheStatusCode, _) = http404Error
print("The status code is: \(justTheStatusCode)")

print("The status code is: \(http404Error.0)")
print("The Status Message is: \(http404Error.1)")

let http200Status = (statusCode: 200, description: "OK")
print("Status Code is: \(http200Status.statusCode)")
print("Status Message is: \(http200Status.description)")

var dingDong: Bool? = nil
print(dingDong)

var mingMong: String? = nil
print(mingMong)

var possibleNumber = "123"
var convertedNumber = Int(possibleNumber)

if convertedNumber != nil {
    print(convertedNumber)
    print(convertedNumber!)
} else {
    print("\(possibleNumber) Can't be converted")
}


if let actualNumber = Int(possibleNumber) {
    print("\(possibleNumber) has integer value \(actualNumber)")
} else {
    print("\(possibleNumber) Can't be converted")
}

var king: String?
king = "Kong"
print(king!)

//Implicitly Unwrapped Opitonal
var ming: String! = "Mong"
print(ming)

if ming == "Mong" {
    print("Voilaaa")
}






