#include <stdio.h>

int main() {
	int a = 20;
	int aa = 100;
	const int b = 30;
	const int bb = 300;

/*
	//RM  OI
	const int *ptr = &b;
	//RI OI
	ptr = &bb; 
	//bb = bb + 1;
	*ptr = bb + 1;
*/


//	int * const ptr = &a;
	int * const ptr = &b;
/*
	//RI OI
	//const int *ptr 
	int const *ptr = &b;
	const int * const ptr = &b;
*/
}
