var a: Int8 = 10
//a = Int8.max + 1

var c: Int8 = Int8.max
var inc: Int8 = 1
//c = c + inc

let minValue = UInt8.min
let maxValue = UInt8.max

print(minValue, maxValue)

let pi = 3.14159
let anotherPi = 3 + 0.14159

//Various Representations
let decimalInteger = 17
let binaryInteger = 0b10001
let octalInteger = 0o21
let hexadecimalInteger = 0x11

let decimalDouble = 12.1875
let exponentDouble = 1.21875e1
let hexadecimalDouble = 0xC.3p0

let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1

var possibleNumber = "123"
var convertedNumber: Int? = Int(possibleNumber)
print(convertedNumber)
print(convertedNumber!)

possibleNumber = "123ABC"
convertedNumber = Int(possibleNumber)
print(convertedNumber)
print(convertedNumber!)



