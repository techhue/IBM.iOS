
for index in 1...5 {
    print(index)
}

for index in 1..<5 {
    print(index)
}

let base  = 3
let power = 10
var answer = 1

for _ in 1...power {
    answer += base
}

print(answer)

let names = ["Anna", "Deepika", "Katrina", "Madhuri", "Alia"]
for name in names {
    print(name)
}

let numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
for (animalName, legCount) in numberOfLegs {
    print("\(animalName)s have \(legCount) legs")
}

var n = 1

ourLoop: while n < 10 {
    print(n)
    if n == 5 {
        continue ourLoop
    } else {
        n = n + 1
    }
}

repeat {
    n = n - 1
    print(n)
} while n > 0


if n < 10 {
    print("Ding")
} else if n == 10 {
    print("Dong")
}

//

let someCharacter: Character = "e"

switch someCharacter {
case "a", "e", "i", "o", "u":
    print("Vowel")
    fallthrough
case "b", "c", "d":
    print("First Three Consonents")
default:
    print("Non Vowel")
}

let welcome = "Hello!"

switch welcome {
    case "Good Morning!":
        print("Good Morning!")
    case "Guten Tag!":
        print("Guten Tag!")
    case "Hello!":
        print("Hello!")
    case "Namasate!":
        print("Namasate")
    default:
        print("Wangooo")
}

let approximateCount = 10
let countedThings = "Moons Orbiting Saturn"
var naturalCount: String = ""
switch  approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several "
default:
    naturalCount = "Forgot Counting..."
}

print("There are \(naturalCount) \(countedThings)")

let somePoint: (Int, Int) =  (1, 1)
switch somePoint {
case (-2...2, -2...2):
    print("Point in Rectangle")
case (0, 0):
    print("Point is Origin")
case (let x, 0):
    print("Point in X-Axis at distance \(x) from origin")
case (0, let y):
    print("Point in Y-Axis at distance \(y) from origin")
default:
    print("Point is outside of box...")
}

let anotherPoint = (1, -1)
switch anotherPoint {
case let (x, y) where x == y:
    print("Point is at x == y line")
case let (x, y) where x == -y :
    print("Point is at x == -y ")
case (_, _):
    print("Point is not on lines")
}

enum CompassPoint {
    case North
    case South
    case East
    case West
}

var direction: CompassPoint = CompassPoint.North

switch direction {
case .North:
    print("Heading N")
case .South:
    print("Heading S")
default:
    print("Neither N/S")
}

