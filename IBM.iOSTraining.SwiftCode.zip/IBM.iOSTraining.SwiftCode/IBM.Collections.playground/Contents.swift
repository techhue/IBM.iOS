var welcome = "Hello World!"
print(welcome)

let longFormDict = Dictionary<String, Int>()
let shortFormDict = [String: Int]()
let emptyDict: [String: Int] = [:]

var airports: [String: String] = ["XYZ": "Toronto", "DUB": "Dublin", "DBX": "Dubai", "BLR": "Bangalore"]
print(airports)
print(airports.count)

if airports.isEmpty {
    print("No Airport Exists")
} else {
    print("Airports Are...")
    print(airports)
}

print(airports["DBX"])
print(airports["HYD"])

airports["XYZ"] = "Toronto Pearson"
print(airports)

airports["HYD"] = "Hyderabad"
print(airports)

airports["BLR"] = nil
print(airports)

airports.removeValue(forKey: "XYZ")
print(airports)


for (airportCode, airportName) in airports {
    print(airportCode, airportName)
}

if let airportName = airports["DUB"] {
    print(airportName)
} else {
    print("Airport Doesn't Exists...")
}

//print(airportCode)

for key in airports.keys {
    print(key)
}

for value in airports.values {
    print(value)
}
