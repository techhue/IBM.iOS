
//Access Controls

//Classes, Structures, Enumerations, Properties, Methodes, Inits and
//Subscripts, Procols, Global Constants, Variable and Functions

//Module and Source Files
//Source File: swift file
//Module - Single Unit of Distributions

//Access Levels
// Public   - Available Anywhere
// Internal - Used within any source file within a module
// Private  - Within A File

//public class
public class PublicClass {
    //Public
    public var somePublicProperty = 0
    var someInternalProperty = 0
    private func somePrivateMethod() { }
}

class InternalClass {
    var someInternalProperty = 0
    private func somePrivateMethod() {   }
}

private class PrivateClass {
    var somePrivateProperty = 0
    func somePrivateMethod() {   }
}




