class Person {
    let name: String
    init(name: String) {
        self.name = name
        print("Person init...", name)
    }
    deinit {
        print("Person deinit...", name)
    }
}

var reference1: Person?
var reference2: Person?
var reference3: Person?

reference1 = Person(name: "Salman Khan")
print(reference1!.name)

reference2 = reference1
print(reference2!.name)

reference3 = reference1
print(reference3!.name)

reference1 = nil
reference3 = nil
//reference2 = nil


// Nothingness Possible For Both Sides i.e. Optionals
class Person2 {
    let name: String
    init(name: String) { self.name = name; print("Person2 init...", name) }
    var apartment: Apartment?
    deinit { print("Person2 deinit...", name)}
}

class Apartment {
    let number: Int
    init(number: Int) { self.number = number; print("Apartment init..", number)}
    weak var tenant: Person2?
    deinit { print("Apartment deinit...", number)}
}

var amir: Person2?
var apartment105: Apartment?

amir = Person2(name: "Amir Khan")
apartment105 = Apartment(number: 105)
amir?.apartment = apartment105
apartment105?.tenant = amir

//amir?.apartment = nil
amir = nil
apartment105 = nil

// One Side Is Nothingness But Another Is NOT

//print("_________ One Side Is Nothingness But Another Is NOT_______")
class Customer {
    let name: String
    var card: CreditCard?
    init(name: String) { self.name = name; print("Customer init...", name) }
    deinit { print("Customer deinit...", name)}
}

class CreditCard {
    let number: Int
    unowned let customer: Customer
    init(number: Int, customer: Customer) {
        self.number   = number
        self.customer = customer
        print("Credit Card init...")
    }
    deinit { print("Credit Card deinit...", number)}
}

var shahRukh: Customer?
shahRukh = Customer(name: "Shahrukh Khan")
shahRukh!.card = CreditCard(number: 1234_4567_8888_9999, customer: shahRukh!)

shahRukh = nil

//Both Sides are NOT Nothingness
class Country {
    let name: String
    //Implicitly Unwrapped Optional
    private var _capitalCity: City!
    var capitalCity: City {
        return _capitalCity
    }
    init(name: String, capitalName: String) {
        self.name = name
        self._capitalCity = City(name: capitalName, country: self)
        print("Country init...", name)
    }
    deinit { print("Country deinit...", name)}
}

class City {
    let name: String
    unowned let country: Country
    init(name: String, country: Country) {
        self.name = name
        self.country = country
        print("City init...", name)
    }
    deinit { print("City deinit...", name)}
}

var country: Country? = Country(name: "Chocolate", capitalName: "Nuts")
print("Country with Capital:", country!.name, country!.capitalCity.name)
country = nil

// Closures....
class HTMLElement {
    let name: String
    let text: String?
    var asHTML: () -> String = {
        [unowned self] in
        if let text = self.text {
            return "<\(self.name)>\(text)</\(self.name)>"
        } else {
            return "<\(self.name)/>"
        }
    }
    init(name: String, text: String? = nil ) {
        self.name = name
        self.text = text
    }
    deinit {
        print("HTTMLElement deinit...")
    }
}
    








