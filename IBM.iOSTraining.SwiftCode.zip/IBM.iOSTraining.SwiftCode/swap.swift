
func swapValues(a: inout Int, b: inout Int) {
    var temp: Int = 0
    temp = a
    a = b
    b = temp
}

var a = 100
var b = 200

swapValues(a: &a, b: &b)
print(a, b)


