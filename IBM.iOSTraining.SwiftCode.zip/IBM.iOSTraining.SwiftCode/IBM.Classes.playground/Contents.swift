struct Resolution {
    var width = 0
    var height = 0
}

class VideoMode {
    var resolution: Resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

let someResolution: Resolution = Resolution()
let someVideoMode: VideoMode  = VideoMode()

print("width of someResolution is \(someResolution.width)")
print("hieght of someResolution is \(someResolution.height)")

print("width of someVideoMode Resolution is \(someVideoMode.resolution.width)")
print("someVideoMode Properties: \(someVideoMode.resolution.width)")
print(someVideoMode.resolution.height, someVideoMode.interlaced, someVideoMode.frameRate, someVideoMode.name)
//print(someVideoMode)

someVideoMode.resolution.width = 1280
print("width of someVideoMode Resolution is \(someVideoMode.resolution.width)")

let vga = Resolution(width: 640, height: 480)
print(vga)
print(vga.height, vga.width)

let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
print(cinema.width, cinema.height)

cinema.width = 2048
print("Cinema Width is Now:", cinema.width)
print("Original Width Was:", hd.width)

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.frameRate = 30.0
tenEighty.name = "1080i"
print(tenEighty.resolution, tenEighty.interlaced, tenEighty.frameRate, tenEighty.name)

let tenEightyCopy = tenEighty
tenEightyCopy.frameRate = 60.0
print(tenEightyCopy.resolution, tenEightyCopy.interlaced, tenEightyCopy.frameRate, tenEightyCopy.name)
print(tenEighty.resolution, tenEighty.interlaced, tenEighty.frameRate, tenEighty.name)

//Identity Operator
if tenEightyCopy === tenEighty {
    print("Pointing to SAME Object")
} else {
    print("Pointing to DIFFERENT Object")
}


