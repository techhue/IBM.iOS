struct FixedLengthRange {
    var firstValue: Int
    let length: Int
}

//var someRange = FixedLengthRange()
//var someRange = FixedLengthRange(firstValue: 0)
var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)

print(rangeOfThreeItems)
rangeOfThreeItems.firstValue = 6
print(rangeOfThreeItems)

let rangeOfFourItems = FixedLengthRange(firstValue: 0, length: 4)
print(rangeOfFourItems)
//rangeOfFourItems.firstValue = 6
//print(rangeOfFourItems)

//Laziness is A Good Idea!
class DataImporter {
    //-- Some Code Here...
    var fileName = "data.txt"
    //---Some Code Here...
    init() {
        print("Importer Object Created")
    }
}

class DataManager {
    lazy var importer = DataImporter()
    var data = [String]()
    init() {
        print("Manager Object Created")
    }
}

let manager = DataManager()
manager.data += ["Some Data"]
manager.data += ["Some More Data"]
print(manager.data)
//print("On Accesing importer")
//print(manager.importer)

struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var width = 0.0, height = 0.0
}
struct Rect {
    var origin = Point()
    var size   = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set {
            origin.x = newValue.x - ( size.width / 2 )
            origin.y = newValue.y - ( size.width / 2 )
        }
    }
    var area: Double {
        //get {
            return size.width * size.height
        //}
    }
}

var square = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
let squareCenter = square.center
print("Center:", squareCenter)
square.origin = Point(x: 1.0, y: 1.0)
print("Center:", square.center)

square.center = Point(x: 8.0, y: 8.0)
print("Origin:", square.origin)
print("Center:", square.center)

print("Area", square.area)

// Property Observers
class StepCounter {
    var totalSteps: Int = 0 {
        willSet(newTotalSteps) {
            print("About to set totalSteps to \(newTotalSteps)")
        }
        didSet {
            if totalSteps > oldValue {
                print("Added \(totalSteps - oldValue) steps")
            }
        }
    }
}
let stepCounter = StepCounter()
stepCounter.totalSteps = 200
stepCounter.totalSteps = 360
stepCounter.totalSteps = 896



//Instance and Type Properties

enum SomeEnumeration {
//    var storedInstanceProperty = "Ding Dong"
    var computedInstanceProperty: Int {
        return 100
    }
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    var storedInstanceProperty = "Ding Dong"
    var computedInstanceProperty: Int {
        return 100
    }
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }
}

/*
 int a[5] = {10, 20, 30, 40, 50};
 int *atpr = a;
 aptr[0] = 100;
 aptr = aptr  + 1;
 a = a + 1;
*/

struct SomeStructure {
    var storedInstanceProperty = "Ding Dong"
    var computedInstanceProperty: Int {
        return 100
    }
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

var some: [SomeStructure] = [SomeStructure(), SomeStructure()]
for s in some {
    print(s)
}


struct AudioChannel {
    static let thresholdLevel = 10
    static var maxInputLevelForAllChannels = 0
    var currentLevel: Int = 0 {
        didSet {
            if currentLevel > AudioChannel.thresholdLevel {
                // cap the new audio level to the threshold level
                currentLevel = AudioChannel.thresholdLevel
            }
            if currentLevel > AudioChannel.maxInputLevelForAllChannels {
                // store this as the new overall maximum input level
                AudioChannel.maxInputLevelForAllChannels = currentLevel
            }
        }
    }
}
var leftChannel = AudioChannel()
var rightChannel = AudioChannel()
leftChannel.currentLevel = 7
print(leftChannel.currentLevel)
print(AudioChannel.maxInputLevelForAllChannels)
rightChannel.currentLevel = 11
print(rightChannel.currentLevel)
print(AudioChannel.maxInputLevelForAllChannels)



