

let heerAndRanja = [ "Ch1: Tere Heer Hai Kaali", "Ch2: Tere Nazaar Deknnee Wali", "Ch3: Ranja Becomes Bufflo Care Taker", "Ch4: Pyaar Hua"]

var chapterCount = 0
for ch in heerAndRanja { 
	if ch.hasPrefix("Ch1") {
		chapterCount += 1 
	}
}

print(chapterCount)

