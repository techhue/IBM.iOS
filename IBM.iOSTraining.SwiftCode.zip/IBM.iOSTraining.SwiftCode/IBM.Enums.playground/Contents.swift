enum CompassPoint {
    case North
    case South
    case East
    case West
}

var directionToHead = CompassPoint.West
directionToHead = .East
// Matching Enumeration Values with a Switch Statement
directionToHead = .South
switch directionToHead {
case .North:
    print("Lots of planets have a north")
case .South:
    print("Watch out for penguins")
case .East:
    print("Where the sun rises")
case .West:
    print("Where the skies are blue")
}



enum Planet {
    case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

let somePlanet = Planet.Earth
switch somePlanet {
case .Earth:
    print("Mostly Harmless")
default:
    print("Not a safe place for humans")
}

// Implicitly Assigned Raw Values
enum PlanetRaw: Int {
    case Mercury = 1, Venuc, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

let earthsOrder = PlanetRaw.Earth.rawValue
// earthsOrder is 3

enum CompassPointRaw: String {
    case North, South, East, West
}
let sunsetDirection = CompassPointRaw.West.rawValue
// sunsetDirection is "West"


// Initializing from a Raw Value
let possiblePlanet = PlanetRaw(rawValue: 7)


