


int sum(int a, int b) {
	int result = 0;
	result = a + b;

	return result;
}


