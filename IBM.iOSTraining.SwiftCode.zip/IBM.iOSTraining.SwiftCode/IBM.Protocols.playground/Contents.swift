
protocol SomeProtocol {
    var mustBeSettable: Int { get set }
    var doesNotNeedToBeSettable: Int { get }
    static var someTypeProperty: Int { get set }
}

protocol FullyNamed {
    var fullName: String { get }
}

struct Person: FullyNamed {
    var fullName: String
}
let john = Person(fullName: "John Hopking")
print(john)

class Starship: FullyNamed {
    var prefix: String?
    var name: String
    init(name: String, prefix: String? = nil ) {
        self.name = name
        self.prefix = prefix
    }
    var fullName: String {
        return ((prefix != nil ? prefix! + " " : "") + name)
    }
}
var vikrantShip = Starship(name: "Vikrant", prefix: "INS")
print(vikrantShip)
print(vikrantShip.fullName)


//________________________________

protocol Cookable {
    func cooking()
}

protocol Playable {
    func play()
}

protocol Superpower {
    func fly()
    func saveWorld()
}

class Human: Superpower, Cookable {
    var power: Superpower?
    func fly() {
        power!.fly()
    }
    func saveWorld() {
        power!.saveWorld()
    }
    
    func  cooking() {
        print("Cooking: Bheja Fry!")
    }
}

extension Human: Playable {
    func play() {
        print("Work Hard... Enjoy Even Harder...")
    }
}

class Spiderman: Superpower {
    func fly() {
        print("Fly Like        :Spiderman")
    }
    func saveWorld() {
        print("Save World Like :Spiderman")
    }
}

class BadSuperman: Superpower {
    func fly() {
        print("Fly Like        :Superman")
    }
    func saveWorld() {
        print("Save World Like :Superman")
    }
}

class Superman: Superpower {
    func fly() {
        print("Fly Like        :Superman")
    }
    func saveWorld() {
        print("Save World Like :Superman")
    }
}

class Ironman: Superpower {
    func fly() {
        print("Fly Like        :Ironman")
    }
    func saveWorld() {
        print("Save World Like :Ironman")
    }
}

class Shaktiman: Superpower {
    func fly() {
        print("Fly Like        :Shaktiman")
    }
    func saveWorld() {
        print("Save World Like :Shaktiman")
    }
}

class HanumanJi: Superpower {
    func fly() {
        print("Fly Like        :HanumanJi")
    }
    func saveWorld() {
        print("Save World Like :HanumanJi")
    }
}

class Thor: Superpower {
    func fly() {
        print("Fly Like        :Thor")
    }
    func saveWorld() {
        print("Save World Like :Thor")
    }
}

class Hulk: Superpower {
    func fly() {
        print("Fly Like        :Hulk")
    }
    func saveWorld() {
        print("Save World Like :Hulk")
    }
}

class Heman {
    func fly() {
        print("Fly Like        :Heman")
    }
    func saveWorld() {
        print("Save World Like :Heman")
    }
}

extension Heman : Superpower { }

var amarjitSingh = Human()
var h = amarjitSingh

h.power = Ironman()
h.fly()
h.saveWorld()
h.cooking()
h.play()

//let avengerPlus: [Superpower] = [Ironman(), Spiderman(), Thor(), Hulk(), Shaktiman(), HanumanJi(), Superman(), amarjitSingh]

print("_________________________")
let im = Ironman()
let spi = Spiderman()
let sup = Superman()
let thor = Thor()
let hulk = Hulk()
let shk = Shaktiman()
let hji = HanumanJi()
let hem = Heman()

let avengers: [Superpower] = [im, spi, sup, thor, hulk, shk, hji, amarjitSingh, hem]

func defendTerritory() {
    for avenger in avengers {
        avenger.fly()
        avenger.saveWorld()
    }
}

defendTerritory()

/*
let avengers: [Superpower] = [im, spi]
//print("_________________________")
//print(avengers[0])
avengers[0].fly()
print(avengers[1])
avengers[1].fly()
*/

var someString: String =
"""
Ding Dong
Ming Mong
King Kong
Zing Zong
"""
/*
print(someString)
var someOptionalString: String? = "Ding Dong"
if let someString = someOptionalString {
    print("String contains value:", someString)
} else {
    print("Nothingness Found...")
}
*/


