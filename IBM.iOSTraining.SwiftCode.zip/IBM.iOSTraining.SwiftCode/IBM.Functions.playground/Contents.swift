func sayHello(personName: String ) -> String {
    let greeting = "Hello! " + personName
    return greeting
}

print(sayHello(personName: "Deepika Padukone"))

func rangeLength(start: Int = 0, end: Int) -> Int {
    return end - start
}

let len = rangeLength(start: 1, end: 10)
print(len)

func sayHelloWorld() -> String {
    return "Hello World!"
}
print(sayHelloWorld())

func sayHelloWorld1() {
    print("Nothing Returned")
}
print(sayHelloWorld1())

func minMax(array: [Int]) -> (min:Int, max:Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

let bounds = minMax(array: [10, 20, -10, -100, 90, 60, 900, 1, 2, 2, 10])
print(bounds.min, bounds.max)

func arithmeticMean(numbers: Double... ) -> Double {
    var total: Double = 0
    for number in numbers {
        total += number
    }
    return total/Double(numbers.count)
}

print(arithmeticMean(numbers: 1, 2, 3, 4, 5))
print(arithmeticMean(numbers: 10, 20, 30))

func swapValues(a: inout Int, b: inout Int) {
    var temp: Int = 0
    temp = a
    a = b
    b = temp
}

var a = 100
var b = 200

swapValues(a: &a, b: &b)
print(a, b)

func sum(a: Int, b: Int) -> Int { return a + b }
func sub(a: Int, b: Int) -> Int { return a - b }
func mul(a: Int, b: Int) -> Int { return a * b }

func calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) -> Int {
    return operation(a, b)
}

var result = calculator(a:10, b:20, operation:sum)
print("Result:", result)

result = calculator(a:10, b:20, operation:sub)
print("Result:", result)

result = calculator(a:10, b:20, operation:mul)
print("Result:", result)


// First Thinking
func moveToZeroSimply(currentState: Int) {
    var currentValue = currentState
    var moveNearer: Int = 0
    moveNearer = ( currentValue > 0 ) ? -1 : 1
    while currentValue != 0 {
        print(currentValue)
        currentValue = currentValue + moveNearer
    }
}
print("First Thinking")
print(moveToZeroSimply(currentState: 4))
print(moveToZeroSimply(currentState: -3))


// Second Thinking
func stepForward(input: Int) -> Int { return input + 1 }
func stepBackward(input: Int) -> Int { return input - 1 }

func chooseSteppingVersion1(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}

var currentValue = -4
let moveToZero = chooseSteppingVersion1(backwards: currentValue > 0 )
while currentValue != 0 {
        print(currentValue)
        currentValue = moveToZero(currentValue)
}





//Third Thinking
// Nested Functions
func chooseStepping(backwards: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int { return input + 2 }
    func stepBackward(input: Int) -> Int { return input - 1 }
    return backwards ? stepBackward : stepForward
}

func move(currentValue: Int) -> Int {
    var movesCount = 0
    var currentValue = currentValue
    let moveToZero = chooseStepping(backwards: currentValue > 0 )
    while currentValue != 0 {
        currentValue = moveToZero(currentValue)
        movesCount = movesCount + 1
    }
    return movesCount
}

var movesCount = move(currentValue: -4)
print(movesCount)

//

// Fourth Thinking
// Nested Functions
func chooseSteppingV4(backwards: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int { return input + 2 }
    func stepBackward(input: Int) -> Int { return input - 1 }
    return backwards ? stepBackward : stepForward
}

func move(currentValue: Int, chooseStep: (Bool) -> (Int) -> Int ) -> Int {
    var movesCount = 0
    var currentValue = currentValue
    let moveToZero = chooseStep(currentValue > 0 )
    while currentValue != 0 {
        currentValue = moveToZero(currentValue)
        movesCount = movesCount + 1
    }
    return movesCount
}

movesCount = move(currentValue: -4, chooseStep: chooseSteppingV4)
print(movesCount)




