
let greeting = "Hello World!"
print(greeting)

var welcomeMessage: String
let pi = 3.1415
//let pi:Float = 3.14

var a: Int8 = 10
//a = Int8.max + 1

var c: Int8 = Int8.max
var inc: Int8 = 1
c = c + inc



