//
//  ViewController.swift
//  MoreUserInterfaceControls
//
//  Created by System Administrator on 7/27/15.
//  Copyright (c) 2015 TechHueSystems. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIActionSheetDelegate
{
    var controlView: THSUIView?
    var nameField: THSUITextField?
    var numberField: THSUITextField?
    var imageView: THSUIImageView?
    var name: THSUILabel?
    var number: THSUILabel?
    var sliderLabel: THSUILabel?
    var slider: THSUISlider?
    var segmented: THSUISegmentedControl?
    var leftSwitch, rightSwitch: THSUISwitch?
    var doSomethingButton: THSUIButton?
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view?.backgroundColor = UIColor(red: 0.4, green: 0.2, blue: 0.6, alpha: 0.9)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView()
    {
        super.loadView()
        controlView = THSUIView(frame: CGRect(origin: self.view!.bounds.origin,
            size: self.view!.bounds.size))
        controlView!.addTarget(self, action: "backgroundTap:", forControlEvents: UIControlEvents.TouchDown)
        self.view!.addSubview(controlView!)
        
        let image:UIImage = UIImage(named: "Apple.png")!
        imageView = THSUIImageView(frame: CGRect(x: 110, y: 30, width: 100, height: 100))
        imageView?.image = image
        controlView?.addSubview(imageView!)
        
        nameField = THSUITextField(frame: CGRect(x: 120, y: 130, width: 170, height: 30))
        nameField?.borderStyle = UITextBorderStyle.RoundedRect
        nameField?.font = UIFont.systemFontOfSize(17)
        nameField?.keyboardType = UIKeyboardType.Default
        nameField?.addTarget(self, action: "textFieldDoneEditing:", forControlEvents: UIControlEvents.EditingDidEndOnExit)
        controlView?.addSubview(nameField!)
        
        name = THSUILabel(frame: CGRect(x: 30, y: 130, width: 80, height: 30))
        name?.text = "Name"
        name?.textAlignment = NSTextAlignment.Left
        name?.font = UIFont.systemFontOfSize(15)
        name?.textColor = UIColor.blackColor()
        controlView?.addSubview(name!)
        
        number = THSUILabel(frame: CGRect(x: 30, y: 170, width: 80, height: 30))
        number?.text = "Number"
        number?.textAlignment = NSTextAlignment.Left
        number?.font = UIFont.systemFontOfSize(15)
        number?.textColor = UIColor.blackColor()
        controlView?.addSubview(number!)
        
        sliderLabel = THSUILabel(frame: CGRect(x: 30, y: 210, width: 40, height: 20))
        sliderLabel?.text = "0"
        sliderLabel?.textAlignment = NSTextAlignment.Left
        sliderLabel?.font = UIFont.systemFontOfSize(15)
        sliderLabel?.textColor = UIColor.blackColor()
        controlView?.addSubview(sliderLabel!)
        
        slider = THSUISlider(frame: CGRect(x: 80, y: 210, width: 210, height: 20))
        slider?.minimumValue = 0
        slider?.maximumValue = 100
        slider?.addTarget(self, action: "sliderChanged:", forControlEvents: UIControlEvents.ValueChanged)
        controlView?.addSubview(slider!)
        
        let item = ["Switches", "Button"]
        segmented = THSUISegmentedControl(items: item)
        segmented?.frame = CGRect(x: 30, y: 240, width: 250, height: 60)
        segmented?.selectedSegmentIndex = 0;
        segmented?.addTarget(self, action: "toggleControls:", forControlEvents: UIControlEvents.ValueChanged)
        controlView?.addSubview(segmented!)
        
        leftSwitch = THSUISwitch(frame: CGRectMake(30, 320, 50, 25))
        leftSwitch?.setOn(true, animated: true)
        
        leftSwitch?.addTarget(self, action: "switchChanged:", forControlEvents: UIControlEvents.ValueChanged)
        controlView?.addSubview(leftSwitch!)
        
        rightSwitch = THSUISwitch(frame: CGRectMake(220, 320, 50, 25))
        rightSwitch?.setOn(true , animated: true)
        rightSwitch?.addTarget(self, action: "switchChanged:", forControlEvents: UIControlEvents.ValueChanged)
        controlView?.addSubview(rightSwitch!)
        
        doSomethingButton = THSUIButton(frame: CGRect(x: 30, y: 320, width: 260, height: 30))
        doSomethingButton?.setTitle("Do Something Button", forState: UIControlState.Normal)
        doSomethingButton?.titleLabel?.font = UIFont.systemFontOfSize(17)
        doSomethingButton?.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        doSomethingButton?.hidden = true
        doSomethingButton?.layer.cornerRadius = 10.0
        doSomethingButton?.layer.borderWidth = 1.0
        doSomethingButton?.layer.borderColor = UIColor.blackColor().CGColor
        doSomethingButton?.layer.shadowOffset = CGSize(width: 10, height: 10)
        doSomethingButton?.layer.shadowOpacity = 8.0
        doSomethingButton?.layer.shadowColor = UIColor.lightGrayColor().CGColor
        
        doSomethingButton?.addTarget(self, action: "buttonPressed:", forControlEvents: UIControlEvents.TouchUpInside)
        controlView?.addSubview(doSomethingButton!)
    }
    
    func textFieldDoneEditing(sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    func backgroundTap(sender: AnyObject)
    {
        nameField?.resignFirstResponder()
        numberField?.resignFirstResponder()
    }
    
    func sliderChanged(sender: UISlider)
    {
        let progress = lroundf(sender.value)
        sliderLabel?.text = NSString(format: "%d", progress) as String
    }
    
    func toggleControls(sender: UISegmentedControl)
    {
        // 0 ==  switch index
        if(sender.selectedSegmentIndex == 0)
        {
            leftSwitch?.hidden = false
            rightSwitch?.hidden = false
            doSomethingButton?.hidden = true
        }
        else
        {
            leftSwitch?.hidden = true
            rightSwitch?.hidden = true
            doSomethingButton?.hidden = false
        }
    }
    
    func switchChanged(sender: UISwitch)
    {
        let setting: Bool = sender.on
        leftSwitch?.setOn(setting, animated: true)
        rightSwitch?.setOn(setting, animated: true)
    }
    
    func buttonPressed(sender: AnyObject)
    {
        let actionSheet: UIActionSheet = UIActionSheet(title: "A",
            delegate: self,
            cancelButtonTitle: "No way",
            destructiveButtonTitle: "Yes, I'am Sure!",
            otherButtonTitles:"")
        actionSheet.showInView(self.view)
    }
    
    func actionSheet(actionSheet: UIActionSheet, didDismissWithButtonIndex buttonIndex: Int)
    {
        if(buttonIndex != actionSheet.cancelButtonIndex)
        {
            var msg: NSString = ""
            let text = nameField?.text as String?
            let coun = text as NSString?
            if(  coun?.length > 0)
            {
                msg = NSString(format: "You can breath easy, %@, everything went OK", nameField!.text!)
            }
            else
            {
                msg = "You can breath easy, everything went OK."
            }
            
            let alert: UIAlertView = UIAlertView(title: "Something was done",
                message: msg as String,
                delegate: nil,
                cancelButtonTitle: "Phew",
                otherButtonTitles: "")
            alert.show()
        }
    }
}

